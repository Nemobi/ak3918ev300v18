#! /mnt/bin/sh

# **Update Log**
# Description：		support spi nand flash update 
# Time:				2019-10-25
# Author:			li_cheng

style=`df -T -h | grep -i "dev/root" | awk '{print $2}'`

norflash="squashfs"
nandflash="yaffs2"

if [ ${style} = ${norflash} ];then
	VAR1="uImage"
	VAR2="root.sqsh4"
	VAR3="usr.sqsh4"
	VAR4="usr.jffs2"

	ZMD5="uImage.md5"
	SMD5="usr.sqsh4.md5"
	JMD5="usr.jffs2.md5"
	RMD5="root.sqsh4.md5"
	echo "system file style is squashfs, flash is spi nor flash"
elif [ ${style} = ${nandflash} ];then
	VAR1="zImage"
 	VAR2="rootfs.yaffs2"
 	VAR3="usr.yaffs2"
 	VAR4="jffs2.yaffs2"
	
 	ZMD5="zImage.md5"
 	SMD5="usr.yaffs2.md5"
	JMD5="jffs2.yaffs2.md5"
 	RMD5="rootfs.yaffs2.md5"
	echo "system file style is yaffs2, flash is spi nand flash"
fi

DIR1="/tmp"
DIR2="/mnt"

update_ispconfig()
{
	rm -rf /etc/jffs2/isp*.conf
}

update_kernel()
{
	echo "check ${VAR1}............................."

	if [ -e ${DIR1}/${VAR1} ] 
	then
		if [ -e ${DIR1}/${ZMD5} ];then
        	result=`md5sum -c ${DIR1}/${ZMD5} | grep OK`
			if [ -z "$result" ];then
				echo "MD5 check ${VAR1} failed, can't updata"
				return
			else
				echo "MD5 check ${VAR1} success"
			fi
		fi
		echo "update ${VAR1} under ${DIR1}...."
   		if [ ${style} = ${norflash} ];then
			updater local KERNEL=${DIR1}/${VAR1}
		elif [ ${style} = ${nandflash} ];then
			updater local KERBAK=${DIR1}/${VAR1}
		fi
   fi  
}

update_squash()
{
	echo "check ${VAR3}.........................."
	if [ -e ${DIR1}/${VAR3} ]
	then
		if [ -e ${DIR1}/${SMD5} ];then
	        result=`md5sum -c ${DIR1}/${SMD5} | grep OK`
	        if [ -z "$result" ];then
				echo "MD5 check ${VAR3} failed, can't updata"
				return
			else
				echo "MD5 check ${VAR3} success"
			fi
		fi
        echo "update ${VAR3} under ${DIR1}...."
 		if [ ${style} = ${norflash} ];then 
			updater local C=${DIR1}/${VAR3}
		elif [ ${style} = ${nandflash} ];then
			updater local BK=${DIR1}/${VAR3}
		fi 
	fi
}

update_jffs2()
{
	echo "check ${VAR4}........................"
	if [ -e ${DIR1}/${VAR4} ]
	then
		if [ -e ${DIR1}/${JMD5} ];then
	        result=`md5sum -c ${DIR1}/${JMD5} | grep OK`
	        if [ -z "$result" ];then
				echo "MD5 check ${VAR4} failed, can't updata"
				return
			else
				echo "MD5 check ${VAR4} success"
			fi
		fi
		echo "update ${VAR4} under ${DIR1}...."
		if [ ${style} = ${norflash} ];then 	
			updater local B=${DIR1}/${VAR4}
		elif [ ${style} = ${nandflash} ];then
			updater local C=${DIR1}/${VAR4}
		fi
	fi
}

update_rootfs_squash()
{
	echo "check ${VAR2}.........................."
    if [ -e ${DIR1}/${VAR2} ]
    then
	    if [ -e ${DIR1}/${RMD5} ];then
	        result=`md5sum -c ${DIR1}/${RMD5} | grep OK`
	        if [ -z "$result" ];then
				echo "MD5 check ${VAR2} failed, can't updata"
				return
			else
				echo "MD5 check ${VAR2} success"
			fi
		fi
        echo "update ${VAR2} under ${DIR1}...."
		if [ ${style} = ${norflash} ];then 		
			updater local A=${DIR1}/${VAR2}
		elif [ ${style} = ${nandflash} ];then
			updater local AK=${DIR1}/${VAR2} 
		fi
	fi
}

# cp busybox to tmp, avoid the command become no use
cp /bin/busybox /tmp/

echo "############ updater_image.sh  begin#############"

if [ ${style} = ${norflash} ];then     
	update_ispconfig
	update_kernel                                                                                             
	update_jffs2                                                                                
	update_squash                                                                               
	update_rootfs_squash 
elif [ ${style} = ${nandflash} ];then                                            
	updater local KERBAK=${DIR2}/${VAR1} AK=${DIR2}/${VAR2} BK=${DIR2}/${VAR3}
fi

/tmp/busybox echo "############ update finished, reboot now #############"

/tmp/busybox sleep 3
/tmp/busybox reboot -f



